#include "cdcatalogue.h"

CDCatalogue::CDCatalogue()
{
    maxsize = 4;
    numcds = 0;
    cds = new CD[maxsize];    //cds array is allocated for space of 4 CD objects
}

CDCatalogue::CDCatalogue(const CDCatalogue& cat)
{
    maxsize = cat.maxsize;
    numcds = cat.numcds;
    CD* cd_copy = new CD[maxsize]; //cds array is allocated for space of maxsize objects
    int i; //initalizer for forloop
    
    for(i=0;i<numcds;i++)
    {
        cd_copy[i] = cat.cds[i];
    }
    
    cds = cd_copy;
}

CDCatalogue::~CDCatalogue()
{
    maxsize = 0;
    numcds = 0;
    delete[] cds; //frees up memory of cds array
}

bool CDCatalogue::Insert(CD disc)
{
    int i; //initializer
    
    for(i=0;i<numcds;i++)
    {
        if( (disc.GetArtist()==cds[i].GetArtist()) && (disc.GetAlbum()==cds[i].GetAlbum()) )
            return false; //if statement checks to see if artist and album are already in catalogue, if found returns false
    }
    
    
    if(numcds==maxsize)
    {
        CD* new_cd_array = new CD[maxsize*2]; //allocates 2x maxsize for new cd array
        for(i=0;i<numcds;i++)
            new_cd_array[i] = cds[i]; //copies all CDs from cds to new cd array
        
        maxsize = maxsize*2; //doubles maxsize
        delete[] cds; //frees memory from old cd array of current object
        cds = new_cd_array; //objects cd array is now equal to the new cd array
    }
    
    cds[numcds] = disc; //inserts disk at last index
    numcds++; //increases number of cds in cdcatalogue
    
    
    
    return true;
}

bool CDCatalogue::Remove(CD disc)
{
    int i; //initializer
    
    for(i=0;i<numcds;i++)
    {
        //looks if artist and albumname match existing cd in catalogue
        if( (disc.GetArtist()==cds[i].GetArtist()) && (disc.GetAlbum()==cds[i].GetAlbum()) )
        {
            cds[i] = cds[numcds-1]; //replaces found cd with cd at last index
            numcds--; //reduces numcds count by 1
            return true; //quits function and returns true
        }
    }

    return false;
    
    //not sure if we should erase last index at cds array, I really don't think it matters because you shouldn't be able to access it.
}






















